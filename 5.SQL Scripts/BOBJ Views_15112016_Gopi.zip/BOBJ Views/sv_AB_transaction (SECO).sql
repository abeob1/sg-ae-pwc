USE [SECO]
GO

/****** Object:  View [dbo].[sv_AB_transaction]    Script Date: 03/03/2016 04:27:44 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO









ALTER VIEW [dbo].[sv_AB_transaction]

AS

Select


T2.Level1,T2.Level1Name,

T2.Level2,T2.Level2Name,

T2.Level3,T2.Level3Name,

T2.Level4,T2.Level4Name,

T2.Level5,T2.Level5Name,
e.[Year] FiscalYear,b.SubNum AS FiscalMonth,
Year(T0.RefDate) as CalYear,month(T0.RefDate) as CalMonth ,

(SELECT Top 1 CAST (AliasName AS VARCHAR(50)) AS AliasName FROM OADM) 'CompnyCode',(SELECT Top 1 CompnyName FROM OADM) 'CompnyName',


TT1.[U_AB_REPORTCODE] [LineofServiceCode],T11.PrcName AS [LineofServiceName],
TT0.[U_AB_REPORTCODE] as [BusinessUnitCode],
T12.PrcName AS [BusinessUnitName],

OO2.PrcCode As [OperatingUnitCode],
T13.PrcName AS [OperatingUnitName],

T0.TransId,T0.TransType,T0.BaseRef,
T1.OcrCode4 ProjectCode,T1.OcrCode5,T15.PrcName OcrCode5Name,T14.PrcName ProjectName,T1.FinncPriod,T1.RefDate,isnull(T1.Debit,0) as Debit,isnull(T1.Credit,0) as Credit,

--(isnull(T1.Debit,0)-isnull(T1.Credit,0)) as 'Amount',

CASE WHEN ISNULL(T1.OcrCode3,'') ='' THEN
	(isnull(T1.Debit,0)-isnull(T1.Credit,0))
	ELSE
	(isnull(T1.Debit,0)-isnull(T1.Credit,0)) *  (OO2.PrcAmount/OO2.OcrTotal)
	END 
as 'Amount',

T3.PeriodCode,T3.PeriodName,T1.Ref1,T1.Ref2,T1.Ref3Line,T1.LineMemo,T1.U_AB_PARTNER,
T0.Series,T0.Number,T0.TransCode,T4.SeriesName,T4.BeginStr,

CASE

WHEN T1.TransType IN (13,14) AND T5.CardCode IS NOT NULL THEN T5.CardCode ELSE NULL END AS CustomerCode,

CASE

WHEN T1.TransType IN (13,14) AND T5.CardCode IS NOT NULL THEN T5.CardName ELSE NULL END AS CustomerName,

CASE

WHEN T1.TransType IN (13,14) AND T5.CardCode IS NOT NULL THEN T6.GROUPNAME ELSE NULL END AS 'Customer GroupName',

CASE

WHEN T1.TransType IN (18,19) AND T5.CardCode IS NOT NULL THEN T5.CardCode ELSE NULL END AS VendorCode,

CASE

WHEN T1.TransType IN (18,19) AND T5.CardCode IS NOT NULL THEN T5.CardName ELSE NULL END AS VendorName,

CASE

WHEN T1.TransType IN (18,19) AND T5.CardCode IS NOT NULL THEN T6.GroupName ELSE NULL END AS 'Vendor GroupName',

T7.U_NAME

from OJDT T0
LEFT JOIN JDT1 T1 on T0.TransId=T1.TransId
LEFT JOIN OOCR OO1 ON OO1.OCRCODE=T1.OcrCode3
LEFT JOIN OCR1 OO2 ON OO1.OcrCode=OO2.OcrCode and (OO2.ValidFrom <= T1.RefDate and Isnull(OO2.ValidTo,'9999-12-31') >= T1.RefDate)
LEFT JOIN sv_AB_ActiveAccountsList T2 ON T1.Account = T2.SegmentedCode
LEFT JOIN sv_AB_PostingPeriod T3 ON T1.FinncPriod = T3.AbsEntry
LEFT JOIN NNM1 T4 ON T4.Series = T0.Series
LEFT JOIN OCRD T5 ON T5.CardCode = T1.ContraAct
LEFT JOIN OCRG T6 ON T6.GroupCode = T5.GroupCode
LEFT JOIN OUSR T7 ON T7.USERID = T0.UserSign

LEFT JOIN (SELECT * FROM OPRC WHERE DimCode = 3) T13 ON OO2.PrcCode = T13.PrcCode
LEFT JOIN (SELECT * FROM OPRC WHERE DimCode = 4) T14 ON T1.OcrCode4 = T14.PrcCode
LEFT JOIN (SELECT * FROM OPRC WHERE DimCode = 5) T15 ON T1.OcrCode5 = T15.PrcCode
LEFT JOIN OFPR b ON T1.FinncPriod = b.AbsEntry	
LEFT JOIN OACP e ON b.Category = e.PeriodCat	
Left Join OPRC TT0 on TT0.[PrcCode] =OO2.PrcCode and  TT0.[DimCode] =3  
Left Join OPRC TT1 on TT1.[PrcCode] =TT0.[U_AB_REPORTCODE] 

LEFT JOIN (SELECT * FROM OPRC WHERE DimCode = 2) T12 ON TT0.[U_AB_REPORTCODE]  = T12.PrcCode
LEFT JOIN (SELECT * FROM OPRC WHERE DimCode = 1) T11 ON  TT1.[U_AB_REPORTCODE] = T11.PrcCode

--(select top 1 TT1.[U_AB_REPORTCODE] FROM OPRC TT1 where TT1.PrcCode=(SELECT top 1 TT0.[U_AB_REPORTCODE] FROM OPRC TT0 WHERE TT0.[PrcCode] =OO2.PrcCode and  TT0.[DimCode] =3 ))


---(SELECT top 1 TT0.[U_AB_REPORTCODE] FROM OPRC TT0 WHERE TT0.[PrcCode] =OO2.PrcCode and  TT0.[DimCode] =3  )










GO


