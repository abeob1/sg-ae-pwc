USE [PWCL_Base_db]
GO

/****** Object:  View [dbo].[sv_AB_JDT1]    Script Date: 03/03/2016 04:26:24 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO








ALTER VIEW [dbo].[sv_AB_JDT1]
AS
	   SELECT Account,isnull(Project,'') Project,isnull(ProfitCode,'') ProfitCode,isnull(OcrCode2,'') OcrCode2,isnull(OcrCode3,'') OcrCode3,isnull(OcrCode4,'') OcrCode4,isnull(OcrCode5,'') OcrCode5,TransType,FinncPriod,ContraAct,Debit,Credit,RefDate,(isnull(Debit,0)-isnull(Credit,0)) 'Amount'
	    FROM JDT1
		
		--UNION ALL
		
		--SELECT Account,isnull(aa.Project,'') Project,Isnull(ProfitCode,'') ProfitCode,isnull(OcrCode2,'') OcrCode2,isnull(OcrCode3,'') OcrCode3,isnull(OcrCode4,'') OcrCode4,isnull(OcrCode5,'') OcrCode5,aa.TransType,cc.AbsEntry,ContraAct,Debit,Credit,aa.RefDate,(isnull(Debit,0)-isnull(Credit,0)) 'Amount'
		--FROM BTF1 aa 
		--LEFT JOIN OBTF bb on aa.BatchNum = bb.BatchNum and aa.TransId = bb.TransId
		--LEFT JOIN OFPR cc on bb.RefDate >= cc.F_RefDate and bb.RefDate <= cc.T_RefDate		
		--WHERE bb.BtfStatus = 'O'




GO

