USE [PWCL_Base_db]
GO

/****** Object:  View [dbo].[sv_AB_BalanceSheetAmount]    Script Date: 03/03/2016 04:26:13 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO







 

 

 

ALTER VIEW [dbo].[sv_AB_BalanceSheetAmount]
AS
  Select T2.Level1,T2.Level1Name,   --   
  T2.Level2,T2.Level2Name,       
  T2.Level3,T2.Level3Name,       
  T2.Level4,T2.Level4Name,       
  T2.Level5,T2.Level5Name,   
  (SELECT Top 1 CAST(AliasName AS VARCHAR(50)) AS Aliasname FROM OADM) 'CompnyCode',(SELECT Top 1 CompnyName FROM OADM) 'CompnyName'
  ,AD.[Balance Sheet Amount],AD.BusinessUnitCode,AD.CalMonth,AD.CalYear,0 FinncPriod,AD.FiscalMonth,AD.FiscalYear,AD.LineofServiceCode,'' OcrCode4,'' 'ProjName','' OcrCode5,'' OperatingUnitCode,'' PeriodCode,'' PeriodName,''  AS [LineofServiceName],'' AS [BusinessUnitName],'' AS [OperatingUnitName] from (Select  AB.Account,AB.FiscalYear,AB.SubNum FiscalMonth,AB.AbsEntry,AB.PeriodCode,AB.PeriodName,'' Project,'' [LineofServiceCode],''  [BusinessUnitCode],'' [OperatingUnitCode],'' OcrCode4,'' OcrCode5,'0' TransType,0 FinncPriod,year(Dateadd(month,3,convert(datetime, (cast(AB.FiscalYear as varchar(10)) +'-' + cast(AB.SubNum as varchar(10)) + '-' + '1'), 101))) CalYear,month(Dateadd(month,3,convert(datetime, (cast(AB.FiscalYear as varchar(10)) +'-' + cast(AB.SubNum as varchar(10)) + '-' + '1'), 101)))  CalMonth 
  ,isnull(Sum(AC.ACT),0) 'Balance Sheet Amount' 
  from (Select Acc1.Account,PP.FiscalYear,PP.SubNum ,PP.AbsEntry,pp.PeriodCode,pp.PeriodName,0 FinncPriod,isnull(SUm(isnull(JD.Debit,0)-isnull(JD.Credit,0)),0) 'ACT'--,DateName(YYYY,JD.RefDate) 'CalYear',Month(JD.RefDate) 'CalMonth' 
  from 
  [dbo].[sv_AB_AccountJE] Acc1 
  Left Join [dbo].[sv_AB_PostingPeriod] PP on Acc1.Account <> PP.SubNum
  left Join [dbo].[sv_AB_JDT1] JD on JD.Account = Acc1.Account and  Month(JD.RefDate)= Month(PP.F_RefDate) and Year(JD.RefDate)= Year(PP.F_RefDate) --JD.FinncPriod = PP.AbsEntry  
  Where isnull(RefDate,(PP.FiscalYear+'-')+PP.SubNum +'-'+'1')  <= isnull(RefDate,(PP.FiscalYear+'-')+PP.SubNum +'-'+'1') 
  Group By Acc1.Account,PP.FiscalYear,PP.SubNum,PP.AbsEntry,pp.PeriodCode,pp.PeriodName
  --,  DateName(YYYY,JD.RefDate),Month(JD.RefDate)
  ) AB,
  (Select Acc1.Account,PP.FiscalYear,PP.SubNum,PP.AbsEntry,pp.PeriodCode,pp.PeriodName,0 FinncPriod,isnull(SUm(isnull(JD.Debit,0)-isnull(JD.Credit,0)),0) 'ACT'--,DateName(YYYY,JD.RefDate) 'CalYear',Month(JD.RefDate) 'CalMonth' 
  from 
  [dbo].[sv_AB_AccountJE] Acc1 
  Left Join [dbo].[sv_AB_PostingPeriod] PP on Acc1.Account <> PP.SubNum
  left Join [dbo].[sv_AB_JDT1] JD on JD.Account = Acc1.Account and Month(JD.RefDate)= Month(PP.F_RefDate) and Year(JD.RefDate)= Year(PP.F_RefDate) --JD.FinncPriod = PP.AbsEntry  
  Where isnull(RefDate,(PP.FiscalYear+'-')+PP.SubNum +'-'+'1')  <= isnull(RefDate,(PP.FiscalYear+'-')+PP.SubNum +'-'+'1') 
  Group By Acc1.Account,PP.FiscalYear,PP.SubNum,PP.AbsEntry,pp.PeriodCode,pp.PeriodName
  ) AC
  where AC.AbsEntry<=AB.AbsEntry and AB.Account=Ac.Account 
  Group By AB.Account,AB.FiscalYear,AB.SubNum,AB.AbsEntry,ab.PeriodCode,AB.PeriodName--,AB.CalYear,Ab.CalMonth
  ) AD
  LEFT JOIN sv_AB_ActiveAccountsList T2 ON  AD.Account = T2.Level5
  
-- WHERE T2.Level1 >= '100000000000000' AND T2.Level1 <= '300000000000000' 





GO


