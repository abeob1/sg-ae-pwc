USE [PWCL_Base_db]
GO

/****** Object:  View [dbo].[sv_AB_PostingPeriod]    Script Date: 03/03/2016 04:27:10 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




ALTER VIEW [dbo].[sv_AB_PostingPeriod]
AS
select e.[Year] AS FiscalYear,b.SubNum, b.AbsEntry, b.[Code] as PeriodCode, b.Name as PeriodName,b.F_RefDate from
OFPR b 
LEFT JOIN OACP e ON b.Category = e.PeriodCat --order by e.[Year],b.SubNum, b.AbsEntry





GO


