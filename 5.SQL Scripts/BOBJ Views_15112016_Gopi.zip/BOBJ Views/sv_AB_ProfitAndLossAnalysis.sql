USE [SEAC]
GO

/****** Object:  View [dbo].[sv_AB_ProfitAndLossAnalysis]    Script Date: 15/11/2016 04:52:21 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW [dbo].[sv_AB_ProfitAndLossAnalysis]
AS
SELECT cast(T0.[AliasName] as Varchar(50)) CompnyCode,T0.CompnyName,					
T2.Level1,T2.Level1Name,							
T2.Level2,T2.Level2Name,							
T2.Level3,T2.Level3Name,							
T2.Level4,T2.Level4Name,							
T2.Level5,T2.Level5Name,							
										
T1.CustomerCode,T1.CustomerName,T4.GroupName CustomerGroupName,T1.VendorCode,T1.VendorName,T6.GroupName VendorGroupName,
CASE T3.frozenFor WHEN 'Y' THEN 'YES' WHEN 'N' THEN 'NO' ELSE NULL END AS BPInactiveFlag,

										
---------------------Modify for each entity based ON their dimensions----------------------------
T1.ProfitCode AS [LineofServiceCode],T11.PrcName AS [LineofServiceName],			
T1.OcrCode2 AS [BusinessUnitCode],T12.PrcName AS [BusinessUnitName],	

T1.OcrCode3 AS [OperatingUnitCode],
--OO2.PrcCode AS [OperatingUnitCode],
T13.PrcName AS [OperatingUnitName],
T1.OcrCode4 As [ProjectCode],T14.PrcName As [ProjectName],					
-------------------------------------------------------------------------------------------------
										
CAST(T1.FiscalYear AS NVARCHAR(4)) AS FiscalYear,T1.FiscalMonth,T1.PeriodCode,T1.PeriodName,
--year(Dateadd(month,3,convert(datetime, (cast(T1.FiscalYear as varchar(10)) +'-' + cast(T1.FiscalMonth as varchar(10)) + '-' + '1'), 101))) CalYear,month(Dateadd(month,3,convert(datetime, (cast(T1.FiscalYear as varchar(10)) +'-' + cast(T1.FiscalMonth as varchar(10)) + '-' + '1'), 101)))  CalMonth ,
T1.CalYear,T1.CalMonth,

										
CASE WHEN Level1 = '400000000000000' THEN Credit - Debit ELSE 0 END AS Act_Turnover,
CASE WHEN Level1 = '500000000000000' THEN Debit - Credit ELSE 0 END AS Act_COS,
CASE WHEN Level1 = '600000000000000' THEN Debit - Credit ELSE 0 END AS Act_OpCost,
CASE WHEN Level1 = '700000000000000' THEN Debit - Credit ELSE 0 END AS Act_NonIncExp,
CASE WHEN Level1 = '800000000000000' THEN Debit - Credit ELSE 0 END AS Act_Tax,

t1.[ActualTrialBalance] AS [ActualTrialBalance],--B.CredLTotal BgtCredit,B.DebLTotal BgtDebit,

CASE WHEN Level1 = '400000000000000' THEN B.CredLTotal - B.DebLTotal ELSE 0 END AS Bgt_Turnover,
CASE WHEN Level1 = '500000000000000' THEN B.DebLTotal - B.CredLTotal ELSE 0 END AS Bgt_COS,
CASE WHEN Level1 = '600000000000000' THEN B.DebLTotal - B.CredLTotal ELSE 0 END AS Bgt_OpCost,
CASE WHEN Level1 = '700000000000000' THEN B.DebLTotal - B.CredLTotal ELSE 0 END AS Bgt_NonIncExp,
CASE WHEN Level1 = '800000000000000' THEN B.DebLTotal - B.CredLTotal ELSE 0 END AS Bgt_Tax, Isnull(B.DebLTotal,0)-Isnull(B.CredLTotal,0) as [BgtTrialBalance]
										
									
FROM (SELECT 'PWC_DEV' AS CompnyCode,* FROM OADM) T0				
LEFT JOIN 									
(										
	SELECT 'PWC_DEV' AS CompnyCode,a.Account AS AcctCode,a.Project,
	(select top 1 TT1.[U_AB_REPORTCODE] FROM OPRC TT1 where TT1.PrcCode=(SELECT top 1 TT0.[U_AB_REPORTCODE] FROM OPRC TT0 WHERE TT0.[PrcCode] =OO2.PrcCode and  TT0.[DimCode] =3 ))
	 as ProfitCode,
	
	(SELECT top 1 TT0.[U_AB_REPORTCODE] FROM OPRC TT0 WHERE TT0.[PrcCode] =OO2.PrcCode and  TT0.[DimCode] =3  ) as OcrCode2,
	OO2.PrcCode OcrCode3,
	--A.OcrCode3	,
	a.OcrCode4,a.OcrCode5,PP.FiscalYear AS FiscalYear,PP.SubNum AS FiscalMonth,
	PP.PeriodCode as PeriodCode,PP.PeriodName as PeriodName,
	DateName(YYYY,a.RefDate) As 'CalYear',
	Month(a.RefDate) 'CalMonth',
	CASE WHEN a.TransType IN (13,14) AND c.CardCode IS NOT NULL THEN c.CardCode ELSE NULL END AS CustomerCode,
	CASE WHEN a.TransType IN (13,14) AND c.CardCode IS NOT NULL THEN c.CardName ELSE NULL END AS CustomerName,
	CASE WHEN a.TransType IN (18,19) AND c.CardCode IS NOT NULL THEN c.CardCode ELSE NULL END AS VendorCode,
	CASE WHEN a.TransType IN (18,19) AND c.CardCode IS NOT NULL THEN c.CardName ELSE NULL END AS VendorName,
	SUM(isnull(Credit,0)) AS Credit,SUM(isnull(Debit,0)) AS Debit, 
	
	CASE WHEN ISNULL(A.OcrCode3,'') ='' THEN
	SUM(isnull(Debit,0)-isnull(Credit,0))
	ELSE
	SUM ((isnull(Debit,0)-isnull(Credit,0)) *  (OO2.PrcAmount/OO2.OcrTotal))
	END 
	as	[ActualTrialBalance]			
	FROM 
	(
		SELECT Account,Project,ProfitCode,OcrCode2,OcrCode3,OcrCode4,OcrCode5,TransType,FinncPriod,ContraAct,Debit,Credit,RefDate,ValidFrom3
		FROM JDT1
		
	) A	
	inner join [dbo].[sv_AB_PostingPeriod] PP on Year(PP.F_RefDate) = Year(A.Refdate)	and Month(PP.F_RefDate) = Month(A.RefDate)					
	LEFT JOIN OOCR OO1 ON OO1.OCRCODE=A.OcrCode3
    LEFT JOIN OCR1 OO2 ON OO1.OcrCode=OO2.OcrCode 

	--And A.RefDate between  OO2.ValidFrom--(CASE when OO2.ValidFrom > A.RefDate then A.ValidFrom3   else OO2.ValidFrom End )
	-- and Isnull(OO2.ValidTo,'9999-12-31')
	AND (	(CASE when OO2.ValidFrom > A.RefDate and OO2.OcrTotal=100 then A.ValidFrom3   else OO2.ValidFrom End )  <= A.RefDate 
	
	and Isnull(OO2.ValidTo,'9999-12-31') > A.RefDate)

	LEFT JOIN OCRD c ON a.ContraAct = c.CardCode
	WHERE a.TransType NOT IN (-3)	--and a.OcrCode3='hc5'		
	
	--AND  ISNULL(A.OcrCode3,'')='52201'
	
	GROUP BY a.Account,a.Project,a.ProfitCode,a.OcrCode2,
	OO2.PrcCode,
	A.OcrCode3,
	a.OcrCode4,a.OcrCode5,PP.FiscalYear,PP.SubNum,--YEar[a.[RefDate]] ,Month[a.[RefDate]],
	PP.PeriodCode,PP.PeriodName,DateName(YYYY,a.RefDate),Month(a.RefDate) ,
	CASE WHEN a.TransType IN (13,14) AND c.CardCode IS NOT NULL THEN c.CardCode ELSE NULL END,
	CASE WHEN a.TransType IN (13,14) AND c.CardCode IS NOT NULL THEN c.CardName ELSE NULL END,
	CASE WHEN a.TransType IN (18,19) AND c.CardCode IS NOT NULL THEN c.CardCode ELSE NULL END,
	CASE WHEN a.TransType IN (18,19) AND c.CardCode IS NOT NULL THEN c.CardName ELSE NULL END--,
	
	
	--DateName(YYYY,a.RefDate),Month(a.RefDate)

) T1 ON T0.CompnyCode = T1.CompnyCode		

			
LEFT JOIN sv_AB_ActiveAccountsList T2 ON T1.AcctCode = T2.SegmentedCode	 
LEFT JOIN (SELECT * FROM OPRC WHERE DimCode = 1) T11 ON T1.ProfitCode = T11.PrcCode
LEFT JOIN (SELECT * FROM OPRC WHERE DimCode = 2) T12 ON T1.OcrCode2 = T12.PrcCode
LEFT JOIN (SELECT * FROM OPRC WHERE DimCode = 3) T13 ON T1.OcrCode3 = T13.PrcCode
LEFT JOIN (SELECT * FROM OPRC WHERE DimCode = 4) T14 ON T1.OcrCode4 = T14.PrcCode
LEFT JOIN (SELECT * FROM OPRC WHERE DimCode = 5) T15 ON T1.OcrCode5 = T15.PrcCode 
LEFT JOIN OCRD T3 ON T1.CustomerCode = T3.CardCode			
LEFT JOIN OCRG T4 ON T3.GroupCode = T4.GroupCode
LEFT JOIN OCRD T7 ON T1.VendorCode = T7.CardCode
LEFT JOIN OCRG T6 ON T7.GroupCode = T6.GroupCode

LEFT JOIN OPRJ T5 ON T1.Project = T5.PrjCode	
			
LEft Join BGT1 B on B.AcctCode=T2.Level5 and B.Line_ID +1 = T1.FiscalMonth
left JOIN OBGT BH on B.BudgId=BH.AbsId and  BH.FinancYear=T1.FiscalYear  
--where BH.FinancYear='' and B.Line_ID +1 =''
										
WHERE T2.Level1 >= '400000000000000' AND T2.Level1 <= '800000000000000'


--AND   ISNULL(T1.OcrCode3,'')='52201'
 





















GO


