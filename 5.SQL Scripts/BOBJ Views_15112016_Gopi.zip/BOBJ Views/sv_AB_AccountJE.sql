USE [PWCL_Base_db]
GO

/****** Object:  View [dbo].[sv_AB_AccountJE]    Script Date: 03/03/2016 04:25:18 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



ALTER VIEW [dbo].[sv_AB_AccountJE]
AS
	   Select Account from JDT1
		UNION
		Select Account from BTF1


GO