USE [PWCL_Base_db]
GO

/****** Object:  View [dbo].[sv_AB_MemoJournals]    Script Date: 03/03/2016 04:26:53 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





ALTER VIEW [dbo].[sv_AB_MemoJournals]
AS
	   Select * from dbo.[@AB_STATITISTICSDATA]
		



GO


