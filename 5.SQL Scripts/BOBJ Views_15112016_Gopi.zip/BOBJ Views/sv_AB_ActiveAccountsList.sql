USE [PWCL_Base_db]
GO

/****** Object:  View [dbo].[sv_AB_ActiveAccountsList]    Script Date: 03/03/2016 04:25:52 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




ALTER VIEW [dbo].[sv_AB_ActiveAccountsList]
AS





(select P.GroupMask,P.GrpLine,
P.Level1,P.Level1Name, 
P.Level2,P.Level2Name, 
P.Level3,P.Level3Name, 
P.Level4,P.Level4Name,
P.Level5,P.Level5Name,

Q.Postable,
case Q.ActType when 'I' then 'Sales' when 'E' then 'Expenditures' else 'Others' end as AcctType,
Q.AcctCode as SegmentedCode


from
(
	select T1.GroupMask,

	case when T4.GrpLine is not null then T4.GrpLine
		 when T3.GrpLine is not null then T3.GrpLine
		 when T2.GrpLine is not null then T2.GrpLine
	else null end as GrpLine,

	T1.AcctCode as Level1,T1.AcctName as Level1Name,
	T2.AcctCode as Level2,T2.AcctName as Level2Name,

	case when T3.AcctCode is not null then T3.AcctCode
		 when T2.AcctCode is not null then T2.AcctCode
	else null end as Level3,
	case when T3.AcctCode is not null then T3.AcctName
		 when T2.AcctCode is not null then T2.AcctName
	else null end as Level3Name,

	case when T4.AcctCode is not null then T4.AcctCode 
		 when T3.AcctCode is not null then T3.AcctCode
		 when T2.AcctCode is not null then T2.AcctCode
	else null end as Level4,
	case when T4.AcctCode is not null then T4.AcctName 
		 when T3.AcctCode is not null then T3.AcctName
		 when T2.AcctCode is not null then T2.AcctName
	else null end as Level4Name,
	
	case when T5.AcctCode is not null then T5.AcctCode	
		 when T4.AcctCode is not null then T4.AcctCode 
		 when T3.AcctCode is not null then T3.AcctCode
		 when T2.AcctCode is not null then T2.AcctCode
	else null end as Level5,	
	case when T5.AcctCode is not null then T5.AcctName	
		 when T4.AcctCode is not null then T4.AcctName 
		 when T3.AcctCode is not null then T3.AcctName
		 when T2.AcctCode is not null then T2.AcctName
	else null end as Level5Name	
	 
	from (select distinct GroupMask,GrpLine,AcctName,case Postable when 'N' then AcctCode else FormatCode end as AcctCode from OACT where FatherNum is null) T1
	left join (select distinct GroupMask,GrpLine,AcctName,case Postable when 'N' then AcctCode else FormatCode end as AcctCode,FatherNum from OACT) T2 on T1.AcctCode = T2.FatherNum
	left join (select distinct GroupMask,GrpLine,AcctName,case Postable when 'N' then AcctCode else FormatCode end as AcctCode,FatherNum from OACT) T3 on T2.AcctCode = T3.FatherNum
	left join (select distinct GroupMask,GrpLine,AcctName,case Postable when 'N' then AcctCode else FormatCode end as AcctCode,FatherNum from OACT) T4 on T3.AcctCode = T4.FatherNum
	left join (select distinct GroupMask,GrpLine,AcctName,case Postable when 'N' then AcctCode else FormatCode end as AcctCode,FatherNum from OACT) T5 on T4.AcctCode = T5.FatherNum
	



) P

left join OACT Q on P.Level5 = Q.FormatCode
where Q.Postable = 'Y')



union 
	Select '3' GroupMask,11 GrpLine, '300000000000000' Level1,'Capital and Reserves' Level1Name,'59999999' Level2,'Profit Period' Level2Name,'59999999' Level3,'Profit Period' Level3Name,'59999999' Level4,'Profit Period' Level4Name,'59999999' Level5,'Profit Period' Level5Name,'Y' Postable,'Others' AcctType,'59999999' SegmentedCode










GO


